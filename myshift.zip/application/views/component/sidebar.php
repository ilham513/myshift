<!-- Sidebar -->
    <nav id="sidebarMenu" class="collapse d-lg-block sidebar collapse bg-white">
      <div class="position-sticky">
        <div class="list-group list-group-flush mx-3 mt-4">
          <a href="<?=site_url('admin')?>" class="list-group-item list-group-item-action py-2 ripple" id="dashboard">
            <i class="fas fa-home fa-fw me-3"></i><span>Dashboard</span>
          </a>

          <a href="<?=site_url('admin/Jadwal')?>" class="list-group-item list-group-item-action py-2 ripple" id="pengiriman">
            <i class="fas fa-table fa-fw me-3"></i><span>Jadwal</span>
          </a>

          <a href="<?=site_url('admin/penyewa')?>" class="list-group-item list-group-item-action py-2 ripple" id="kurir">
            <i class="fas fa-user fa-fw me-3"></i><span>Karyawan </span>
          </a>

          <a href="<?=site_url('admin/waktu')?>" class="list-group-item list-group-item-action py-2 ripple" id="gudang"><i
              class="fas fa-clock fa-fw me-3"></i><span>Waktu</span>
		  </a>

          <a href="<?=site_url('admin/absen')?>" class="list-group-item list-group-item-action py-2 ripple" id="gudang"><i
              class="fas fa-check fa-fw me-3"></i><span>Absen</span>
		  </a>

        </div>
      </div>
    </nav>
    <!-- Sidebar -->