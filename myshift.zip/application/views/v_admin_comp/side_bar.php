<nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="<?=site_url('admin')?>">
                  <span data-feather="home"></span>
                  Dashboard
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?=site_url('admin/jadwal')?>">
                  <span data-feather="bar-chart-2"></span>
                  Jadwal
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?=site_url('admin/penyewa')?>">
                  <span data-feather="users"></span>
                  Karyawan
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?=site_url('admin/waktu')?>">
                  <span data-feather="clock"></span>
                  Waktu
                </a>
              </li>
            </ul>
        </nav>
